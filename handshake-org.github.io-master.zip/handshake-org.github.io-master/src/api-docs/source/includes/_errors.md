# Errors
Any errors will be returned with an http status code other than 200, containing a JSON object in the form:

`{"error": { message: "message" } }`
